public class EspacoDesportivo {
    private String designacao;

    // Construtor
    public EspacoDesportivo(String designacao) {
        this.designacao = designacao;
    }

    // Getter e setter para designacao
    public String getDesignacao() {
        return designacao;
    }

    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    // Outros métodos relacionados aos espaços desportivos
}
